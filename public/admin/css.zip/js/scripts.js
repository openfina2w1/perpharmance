$(document).ready(function(){
    $(".verify_btn").click(function(){
        var user_id =  $(this).attr('data-id');
        Swal.fire({
            title: 'Are you sure?',
            text: "You want to verified this user",
            icon: 'warning',
            animation: false,
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No', 
        }).then((result) => {
            if (result.value) {
                $(".verify_btn").css('pointer-events','none');
                $(".verify_btn").html("Please wait...");
                
                $.ajax({
                    url: "verify",
                    type: 'PUT',
                    data: { "_token": $('meta[name="csrf-token"]').attr('content'), user_id: user_id },
                    dataType: 'json',
                    success: function(response) {
                        if(response.status == 'success'){
                            $(".response_success").html(response.message);
                            $(".response_success").show();
                            $(".verify_btn").html("Verified");
                            $(".verify_reject_btn").css('pointer-events','none');
                        } else{
                            $(".response_error").html(response.message);
                            $(".response_error").show();
                            $(".verify_btn").html("Verify");
                        }
                    },
                    error: function(xhr, status, error) {
                        $(".response_error").html("Something wrong. Please try again!");
                        $(".response_error").show();
                        $(".verify_btn").html("Verify");
                    },
                    complete : function() {
                        setTimeout(function(){
                            $(".alert").hide();
                        }, 7000);
                    }
                });
            }
        });
    });
    
    $(".verify_reject_btn").click(function(){
        $('.bd-example-modal-sm').modal('show');
        $("#user_id").val($(this).attr('data-id'));
    });
    
    $(".modal_close").click(function(){
        $('.bd-example-modal-sm').modal('hide')
        $(".btn_user_reject").prop('disabled', false);
    });

    $(".btn_user_reject").click(function(){
        $(".btn_user_reject").prop('disabled', true);
        $(".btn_user_reject").html("Please wait...");
        var reject_cause =  $("#reject_cause").val();
        var user_id =  $("#user_id").val();

        $.ajax({
            url: "user-reject",
            type: 'PUT',
            data: { "_token": $('meta[name="csrf-token"]').attr('content'), "user_id": user_id, "reject_cause": reject_cause },
            dataType: 'json',
            success: function(response) {
                if(response.status == 'success'){
                    $(".response_success").html(response.message);
                    $(".response_success").show();
                    $(".verify_reject_btn").css('pointer-events','none');
                    $(".verify_reject_btn").html("Rejected");
                    $(".verify_btn").css('pointer-events','none');
                } else{
                    $(".response_error").html(response.message);
                    $(".response_error").show();
                }
            },
            error: function(xhr, status, error) {
                $(".response_error").html("Something wrong. Please try again!");
                $(".response_error").show();
            },
            complete : function() {
                $('.bd-example-modal-sm').modal('hide')
                $(".btn_user_reject").prop('disabled', true);
                $(".btn_user_reject").html("Submit");
                $("#reject_cause").val('');
                $("#user_id").val('');
                setTimeout(function(){
                    $(".alert").hide();
                }, 7000);
            }
        });
    });
    
});